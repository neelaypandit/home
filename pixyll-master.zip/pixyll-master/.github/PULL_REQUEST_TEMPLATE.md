## Read this before making a pull request

### There's no need to make a pull request against the original repo for personal changes

You can publish your copy of Pixyll from your fork using Github Pages, without ever needing to make a pull request. The original source repository (johnotander/pixyll) exists as a template.

To learn more look [here](https://stackoverflow.com/questions/3611256/forking-vs-branching-in-github)
